import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  function handleLogin(e) {
    e.preventDefault();
    navigate("/landing");
  }

  return (
    <div className="page-shell">
      <div className="auth-card">
        <div className="hero-badge">🎬 MovieHub</div>
        <h1>Welcome back</h1>
        <p className="tagline">Login to continue to your movie dashboard.</p>

        <form className="form" onSubmit={handleLogin}>
          <label>
            Email
            <input type="email" placeholder="Enter email" required />
          </label>

          <label>
            Password
            <input type="password" placeholder="Enter password" required />
          </label>

          <button type="submit" className="primary-btn full-btn">
            Login
          </button>
        </form>

        <p className="auth-link">
          Don’t have an account? <Link to="/register">Register</Link>
        </p>
      </div>
    </div>
  );
}