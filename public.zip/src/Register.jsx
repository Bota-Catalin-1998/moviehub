import { Link, useNavigate } from "react-router-dom";

export default function Register() {
  const navigate = useNavigate();

  function handleRegister(e) {
    e.preventDefault();
    navigate("/landing");
  }

  return (
    <div className="page-shell">
      <div className="auth-card">
        <div className="hero-badge">🎬 MovieHub</div>
        <h1>Create account</h1>
        <p className="tagline">Join MovieHub and manage your movies easily.</p>

        <form className="form" onSubmit={handleRegister}>
          <label>
            Username
            <input type="text" placeholder="Enter username" required />
          </label>

          <label>
            Email
            <input type="email" placeholder="Enter email" required />
          </label>

          <label>
            Password
            <input type="password" placeholder="Enter password" required />
          </label>

          <button type="submit" className="primary-btn full-btn">
            Register
          </button>
        </form>

        <p className="auth-link">
          Already have an account? <Link to="/">Login</Link>
        </p>
      </div>
    </div>
  );
}